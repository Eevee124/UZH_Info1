from abc import ABC, abstractmethod


class GeometricObject:

    def __init__(self, color, filled):
        pass

    def get_color(self):
        pass

    def set_color(self, color):
        pass

    def get_filled(self):
        pass

    def set_filled(self, filled):
        pass

    def get_area(self):
        pass

    def get_volume(self):
        pass
