from public.geometric_object import GeometricObject


class Cube(GeometricObject):
    def __init__(self, side_length, color, filled):
        pass

    def get_side_length(self):
        pass

    def set_side_length(self, side_length):
        pass

    def get_area(self):
        pass

    def get_volume(self):
        pass
