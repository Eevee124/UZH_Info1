from public.geometric_object import GeometricObject


class Cylinder(GeometricObject):

    def __init__(self, radius, height, color, filled):
        pass

    def get_radius(self):
        pass

    def get_height(self):
        pass

    def get_area(self):
        pass

    def get_volume(self):
        pass
