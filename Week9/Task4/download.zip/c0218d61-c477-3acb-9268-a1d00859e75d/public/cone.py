from public.geometric_object import GeometricObject


class Cone(GeometricObject):

    def __init__(self, radius, vertical_height, slant_height, color, filled):
        pass

    def get_radius(self):
        pass

    def get_vertical_height(self):
        pass

    def get_slant_height(self):
        pass

    def get_area(self):
        pass

    def get_volume(self):
        pass
